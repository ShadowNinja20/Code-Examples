#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include "huffman.h"

static int _compare_fn(const void* o1, const void* o2) {
	const TreeNode* tree1 = o1;
	const TreeNode* tree2 = o2;
	if(((tree1 -> frequency) - ((tree2) -> frequency)) != 0) {
		return ((tree1) -> frequency - (tree2) -> frequency);
	}
	else {
		if(tree1 -> character == '\0') {
			return (256 - (int)(tree2 -> character));
		}
		else if(tree2 -> character == '\0') {
			return ((int)(tree1 -> character) - 256);	
		}
		else {
			return ((int)(tree1 -> character) - (int)(tree2 -> character));
		}
	}
}

Node* make_huffman_pq(Frequencies freqs) {
	Node* huffman_node = NULL;
	for(int i = 0; i < 256; i++) {
		if(freqs[i] > 0) {
			TreeNode* value = malloc(sizeof(*value));
			*value = (TreeNode) { .character = (char)i, .frequency = freqs[i], .left = NULL, .right = NULL };
			pq_enqueue(&huffman_node, value, _compare_fn);
		}
	}
	return huffman_node;
}

TreeNode* make_huffman_tree(Node* head) {
	if(head == NULL) {
		return NULL;
	}
	else if(head -> next == NULL) {
	//	TreeNode* new_node = malloc(sizeof(*new_node));
	//	*new_node = (TreeNode) { .character = '\0', .frequency = 0, .left = NULL, .right = NULL };


	}
	while(head -> next != NULL) {
		TreeNode* new_node = malloc(sizeof(*new_node));
		*new_node = (TreeNode) { .character = '\0', .frequency = 0, .left = NULL, .right = NULL };
		Node* node1 = pq_dequeue(&head);
		Node* node2 = pq_dequeue(&head);
		node1 -> next = NULL;
		node2 -> next = NULL;
		if((((TreeNode*)(node1 -> a_value)) -> frequency) < (((TreeNode*)(node2 -> a_value)) -> frequency)) {
			new_node -> left = (TreeNode*)(node1 -> a_value);
			new_node -> right = node2 -> a_value;
		}
//		else if((((TreeNode*)(node1 -> a_value)) -> frequency) > (((TreeNode*)(node2 -> a_value)) -> frequency)) {
		//	new_node -> left = node2 -> a_value;
		//	new_node -> right = node1 -> a_value;
//		}
		else if((int)(((TreeNode*)(node1 -> a_value)) -> character) < (int)(((TreeNode*)(node2 -> a_value)) -> frequency)) {
			new_node -> left = node1 -> a_value;
			new_node -> right = node2 -> a_value;
		}	
		else {
			new_node -> left = node2 -> a_value;
			new_node -> right = node1 -> a_value;
		}

		new_node -> frequency = (((TreeNode*)(node1 -> a_value)) -> frequency) + (((TreeNode*)(node2 -> a_value)) -> frequency);

		pq_enqueue(&head, new_node, _compare_fn);
/*
		for(Node* currs = head; currs != NULL; currs = currs -> next) {
			printf(" linked list %c %ld\n",((TreeNode*)(currs -> a_value)) -> character, ((TreeNode*)(currs -> a_value)) -> frequency);
		}
		printf("\n\n");
*/
		free(node1);
		free(node2);
	}
	TreeNode* final = head -> a_value; 
	free(head);
	return(final);
	//return head -> a_value;
}

void destroy_huffman_tree(TreeNode** a_root) {
	while(*a_root != NULL) {
		destroy_huffman_tree(&((*a_root) -> left));
		destroy_huffman_tree(&((*a_root) -> right));
		free(*a_root);
		*a_root = NULL;
	}
	*a_root = NULL;
		
}
/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */
