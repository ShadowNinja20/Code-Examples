#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include "huffman.h"
#include "miniunit.h"

/*
static void _print(TreeNode* head) {
	if(head -> left != NULL) {
		_print(head -> left );
		printf("freq: %ld character: %c\n", head -> left -> frequency, head -> left -> character);
	}
	if (head -> right != NULL) {
		_print(head -> right);
		printf("freq: %ld character: %c\n", head -> right -> frequency, head -> right -> character);
	}
}

static void _destroy_fn(void* a_value){
	free((a_value));
}
*/

int _test_1() {
	mu_start();

	Frequencies freqs = {0}; 
	const char* error;
	calc_frequencies(freqs, "test.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);

	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);

	mu_check(ahead -> frequency == 25);
	mu_check(ahead -> left -> frequency == 10);

	mu_check(ahead -> left -> left -> frequency == 5);
	mu_check(ahead -> right -> frequency == 15);

	destroy_huffman_tree(&ahead) ;

	mu_end();
}

int _test_2() {
	mu_start();

	Frequencies freqs = {0}; 
	const char* error;
	calc_frequencies(freqs, "test6.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);

	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);

	//mu_check(ahead -> frequency == 1);
	destroy_huffman_tree(&ahead) ;

	mu_end();
}

int _test_3() {
	mu_start();

	Frequencies freqs = {0}; 
	const char* error;
	calc_frequencies(freqs, "test2.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);

	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);

	mu_check(ahead -> frequency == 23);
//	mu_check(ahead -> left -> frequency == 10);
//	mu_check(ahead -> right -> frequency == 15);

	destroy_huffman_tree(&ahead) ;

	mu_end();
}

int _test_4() {
	mu_start();

	Frequencies freqs = {0}; 
	const char* error;
	calc_frequencies(freqs, "test3.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);

	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);

	mu_check(ahead -> frequency == 85);
//	mu_check(ahead -> left -> frequency == 10);
//	mu_check(ahead -> right -> frequency == 15);

	destroy_huffman_tree(&ahead) ;

	mu_end();
}

int _test_5() {
	mu_start();

	Frequencies freqs = {0}; 
	const char* error;
	calc_frequencies(freqs, "test4.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);

	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);

	mu_check(ahead -> frequency == 2);
//	mu_check(ahead -> left -> frequency == 10);
//	mu_check(ahead -> right -> frequency == 15);

	destroy_huffman_tree(&ahead) ;
	mu_end();
}

int _test_6() {
	mu_start();

	Frequencies freqs = {0}; 
	const char* error;
	if(calc_frequencies(freqs, "test6.txt", &error)) {
		Node* head = NULL;
		head = make_huffman_pq(freqs);
		TreeNode* ahead = NULL;
		ahead = make_huffman_tree(head);
		destroy_huffman_tree(&ahead) ;
	}
	else {
		printf("Error: %s", error);
	}
	mu_end();
}

int main(int argc, char* argv[]) {
	mu_run(_test_1);
	mu_run(_test_2);
	mu_run(_test_3);
	mu_run(_test_4);
	mu_run(_test_5);
	mu_run(_test_6);

/*	mu_run(_test_2);
Frequencies freqs = {0}; 
	const char* error;
	calc_frequencies(freqs, "test1.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);
for(Node* curr = head; curr != NULL; curr = curr -> next) {
		printf("indeed%c %ld\n",((TreeNode*)(curr -> a_value)) -> character, ((TreeNode*)(curr -> a_value)) -> frequency);
	}

	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);

	printf("%ld", (ahead -> frequency));
	destroy_huffman_tree(&ahead) ;
*/

/*	
	Frequencies freqs = {0};
	const char* error;
	calc_frequencies(freqs, "test.txt", &error);
	Node* head = NULL;
	head = make_huffman_pq(freqs);
	for(Node* curr = head; curr != NULL; curr = curr -> next) {
		printf("%c %ld\n",((TreeNode*)(curr -> a_value)) -> character, ((TreeNode*)(curr -> a_value)) -> frequency);
	}
	TreeNode* ahead = NULL;
	ahead = make_huffman_tree(head);
	_print(ahead);
	printf("%ld\n",ahead -> frequency );
	destroy_huffman_tree(&ahead) ;
*/
	return EXIT_SUCCESS;
}
/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */
